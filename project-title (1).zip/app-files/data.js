var APP_DATA = {
  "scenes": [
    {
      "id": "0-01-6080",
      "name": "01-6080",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.09938851801511106,
          "pitch": 0.1934703461473326,
          "rotation": 6.283185307179586,
          "target": "1-01-6081"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-01-6081",
      "name": "01-6081",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.275319040472498,
          "pitch": 0.2192149216717283,
          "rotation": 0.7853981633974483,
          "target": "2-01-6082"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.38009392598987546,
          "pitch": 0.07414197037865655,
          "title": "Rent A Car",
          "text": "Rent a car for the duration of your stay. Simply fill out our ameneties form and send to amenitites@potatolodge.co.bw"
        }
      ]
    },
    {
      "id": "2-01-6082",
      "name": "01-6082",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
